﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SBA_BACKEND.Resources
{
    public class SaveTechnicalResource : SaveUserResource
    {
        public string Description { get; set; }
    }
}
